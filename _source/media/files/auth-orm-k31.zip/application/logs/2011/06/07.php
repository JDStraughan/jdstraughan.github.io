<?php defined('SYSPATH') or die('No direct script access.'); ?>

2011-06-07 22:14:12 --- ERROR: ErrorException [ 1 ]: Using $this when not in object context ~ APPPATH/views/user/create.php [ 11 ]